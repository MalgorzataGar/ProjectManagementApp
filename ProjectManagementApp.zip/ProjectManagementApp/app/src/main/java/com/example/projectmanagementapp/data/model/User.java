package com.example.projectmanagementapp.data.model;

import java.util.List;

public class User {
    public String Name;
    public List<Team> Teams;
    public List<Task> Tasks;
}