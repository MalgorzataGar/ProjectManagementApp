package com.example.projectmanagementapp.data.model;

import java.util.List;

public class Team {
    public String Name;
    public List<User> Members;
    public List<Task> Tasks;
    public User Creator;
}
