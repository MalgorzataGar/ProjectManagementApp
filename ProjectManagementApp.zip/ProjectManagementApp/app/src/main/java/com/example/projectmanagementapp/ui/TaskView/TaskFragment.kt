package com.example.projectmanagementapp.ui.TaskView

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.projectmanagementapp.R
import com.example.projectmanagementapp.data.model.Task
import com.example.projectmanagementapp.AwsAPI.AwsApi
import com.example.projectmanagementapp.data.model.User

class TaskFragment : Fragment() {

    private lateinit var taskViewModel: TaskViewModel
    private lateinit var root :View

    companion object {
        var TAG = TaskFragment::class.java.simpleName
        const val ARG_POSITION: String = "positioin"

        fun newInstance(): TaskFragment {
            var fragment = TaskFragment();
            val args = Bundle()
            args.putInt(ARG_POSITION, 1)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        taskViewModel =
            ViewModelProviders.of(this).get(TaskViewModel::class.java)
        root = inflater.inflate(R.layout.fragment_task, container, false);
        val id = arguments?.getString("taskID")
        initView(id)
        return root
    }

    private fun initView(id: String?) {
        val task : Task = GetTaskByID(id)
        val idTextView: TextView = root.findViewById(R.id.text_details_id)
        val nameTextView: TextView = root.findViewById(R.id.text_details_name)
        val creatorTextView: TextView = root.findViewById(R.id.text_details_creator)
        val deadlineTextView: TextView = root.findViewById(R.id.text_details_deadline)
        val descriptionTextView: TextView = root.findViewById(R.id.text_details_description)
        val priorityTextView: TextView = root.findViewById(R.id.text_details_priority)
        val stateTextView: TextView = root.findViewById(R.id.text_details_state)
        taskViewModel.text.observe(viewLifecycleOwner, Observer {
            idTextView.text = id
            nameTextView.text = task.taskName
            creatorTextView.text = GetCreatorById(task.creatorID)?.getName()
            deadlineTextView.text = task.deadline
            priorityTextView.text = task.priority
            stateTextView.text = task.state
            descriptionTextView.text = task.taskDescription
        })
    }

    private fun GetCreatorById(creatorID: String?): User? {
        //return AwsApi.getUser(creatorID)
        return null
    }


    private fun GetTaskByID(id: String?): Task {
       // return AwsApi.getTask(id)
        return Task("2","12.05.2020", listOf("1"),
            "groupID",id,"important","new","test task","Name")
    }


}
