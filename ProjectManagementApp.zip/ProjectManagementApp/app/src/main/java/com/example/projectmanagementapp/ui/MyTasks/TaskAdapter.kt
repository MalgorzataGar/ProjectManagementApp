import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.projectmanagementapp.R
import com.example.projectmanagementapp.data.model.Task
import com.example.projectmanagementapp.extensions.inflate

class RecyclerAdapter(tasks: ArrayList<Task>) : RecyclerView.Adapter<RecyclerAdapter.TaskHolder>()  {

    private val _tasks: ArrayList<Task> = tasks
    override fun onBindViewHolder(holder: RecyclerAdapter.TaskHolder, position: Int) {
        val itemTask = _tasks[position]
        holder.bindPhoto(itemTask)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerAdapter.TaskHolder {
        val inflatedView = parent.inflate(R.layout.task_item, false)
        return TaskHolder(inflatedView)
    }

    override fun getItemCount(): Int {
       return _tasks.size
    }
    public class TaskHolder(v: View) : RecyclerView.ViewHolder(v),
        View.OnClickListener {
        private var view: View = v
        private var task: Task? = null

        init{
            v.setOnClickListener(this)
        }
        override fun onClick(v: View?) {
            Log.d("RecyclerView", "CLICK!")
        }
        companion object {
            private val TASK_KEY = "TASK"
        }

    }
}
